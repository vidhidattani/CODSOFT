from django.contrib import admin
from django.urls import path
from todoapp import views
urlpatterns = [
    path('',views.todo,name='home'),
    path('edit/<int:pk>/',views.updatetoo, name='update'),
    path('delete/<int:pk>/',views.deletetask, name='delete'),
    path('complete/<int:pk>/',views.completetask, name='complete'),
]