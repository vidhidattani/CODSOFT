from django.db import models

# Create your models here.
class Tasklist(models.Model):
    Title = models.CharField(max_length=120)
    Desc = models.TextField()
    date = models.DateField()
    complete= models.BooleanField(default=False)

    def __str__(self):
        return self.Title