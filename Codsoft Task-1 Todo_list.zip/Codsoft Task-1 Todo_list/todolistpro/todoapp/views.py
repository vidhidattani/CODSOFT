from django.shortcuts import get_object_or_404, redirect, render,HttpResponse
from django.contrib import messages
from todoapp.models import Tasklist
from datetime import datetime
# Create your views here.
def todo(request):
    modelobj = Tasklist.objects.all()
    context = {"modelobj": modelobj}
    
    if request.method=="POST":
        title = request.POST.get("title")
        desc = request.POST.get("desc")
        taskobj = Tasklist(Title=title, Desc=desc,date=datetime.today())
        taskobj.save()
        messages.success(request,'task has been sent.')

        modelobj = Tasklist.objects.all()
        context = {"modelobj": modelobj}
    return render(request,'index.html', context)

def updatetoo(request, pk):
    task = get_object_or_404(Tasklist, pk=pk)
    if request.method == "POST":
        title = request.POST.get("title")
        desc = request.POST.get("desc")
        task.Title = title
        task.Desc = desc
        task.date = datetime.today()
        task.save()
        messages.success(request, 'Task has been updated.')
        return redirect('home')

    context = {"task": task}
    return render(request, 'update.html', context)

def deletetask(request, pk):
    task= get_object_or_404(Tasklist,id=pk)
    task.delete()
    messages.success(request, 'Task has been deleted.')

    modelobj = Tasklist.objects.all()
    context = {"modelobj": modelobj}
    return render(request,'index.html', context)

def completetask(request,pk):
    task = get_object_or_404(Tasklist,id=pk)
    task.complete=True
    task.save()
    messages.success(request, 'Task status has been changed.')

    modelobj = Tasklist.objects.all()
    context = {"modelobj": modelobj}
    return render(request,'index.html', context)