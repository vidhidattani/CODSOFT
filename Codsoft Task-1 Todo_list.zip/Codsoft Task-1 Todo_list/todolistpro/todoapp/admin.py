from django.contrib import admin
from todoapp.models import Tasklist
# Register your models here.
admin.site.register(Tasklist)