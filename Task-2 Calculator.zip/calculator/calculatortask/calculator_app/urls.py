from django.urls import path
from calculator_app import views
urlpatterns = [
    path('', views.Calc,name='calc'),
]
