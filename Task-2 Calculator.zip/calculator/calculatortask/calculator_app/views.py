from django.shortcuts import render

# Create your views here.

def Calc(request):
    ans = ""
    numberinput = ""
    if request.method == "POST":
        numberinput = request.POST.get('ans', '')
        action = request.POST.get('action')
        if action == "C":
            numberinput = ""
        elif action == "=":
            try:
                ans = eval(numberinput)
                numberinput = str(ans)
            except Exception as e:
                numberinput = "Error"
        else:
            numberinput += action

    return render(request, 'index.html', {'ans': numberinput})