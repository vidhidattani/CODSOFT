from django.shortcuts import redirect, render
from contact_app.models import Contacttbl
# Create your views here.

def index(request):
    contacts = Contacttbl.objects.all()   
    search = request.GET.get('search-area')
    if search:
        contacts = Contacttbl.objects.filter(name__icontains=search)
    else:
        contacts = Contacttbl.objects.all()
        search= ''
    return render(request, 'index.html', {'contacts': contacts, 'search': search})

def addContact(request):
    if request.method == 'POST':

        new_contact = Contacttbl(
            name=request.POST['name'],
            phone_number=request.POST['phone-number'],
            email=request.POST['email'],
            address=request.POST['address'],
            )
        new_contact.save()
        return redirect('/')

    return render(request, 'new.html')

def editContact(request, pk):
    contact = Contacttbl.objects.get(id=pk)

    if request.method == 'POST':
        contact.name = request.POST['name']
        contact.phone_number = request.POST['phone-number']
        contact.email = request.POST['email']
        contact.address = request.POST['address']
        contact.save()

        return redirect('/profile/'+str(contact.id))
    return render(request, 'edit.html', {'contact': contact})

def deleteContact(request, pk):
    contact = Contacttbl.objects.get(id=pk)

    if request.method == 'POST':
        contact.delete()
        return redirect('/')

    return render(request, 'delete.html', {'contact': contact})

def contactProfile(request, pk):
    contact = Contacttbl.objects.get(id=pk)
    return render(request, 'contact-profile.html', {'contact':contact})