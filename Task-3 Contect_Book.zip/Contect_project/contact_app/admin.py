from django.contrib import admin
from contact_app.models import Contacttbl

# Register your models here.

admin.site.register(Contacttbl)
